package scripts;

public class SampleHelper {
    public static String getHello() {
        return "Hello World!";
    }
}
