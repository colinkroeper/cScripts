package scripts.dax_api.walker.models;

public interface WaitCondition {
    boolean action();
}
