package scripts.dax_api.shared.helpers.magic;


public interface Validatable {
    boolean canUse();
}
